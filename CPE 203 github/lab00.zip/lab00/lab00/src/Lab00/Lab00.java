package Lab00;

/* this part is as comment similar to comments in Python
CPE/CSC 203 Lab00
Name: Arya Sastry

Section: 03

*/
public class Lab00 {

   // function counts the given character in the given string
   // str str -> int

   static int char_count(String s, char c) {
      int count = 0;

      for (char j : s.toCharArray()) {
         if (s.charAt(j) == c) {
            count += 1;
         }
      }
      return count;
   }

   public static void main(String[] arguments) {
      // declaring and initializing some variables
      int x = 5;

      String y = "hello";

      float z = 9.8f;

      // printing the variables

      System.out.println("x: " + x + " y: " + y + " z: " + z);

      // a list (make an array in java)

      int[] nums = {3, 6, -1, 2};

      for (int num : nums) {
         System.out.println(num);
      }

      // call a function

      int numFound = char_count(y, 'l');

      System.out.println("Found: " + numFound);

      // a counting for loop

      for (int k = 1; k < 11; k ++) {
         System.out.print(k + " ");
      }


   }

}