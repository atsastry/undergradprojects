
public class Node {

    private int digit;
    private Node next;
    
    public Node (int digit, Node next) {
        this.digit = digit;
        this.next = next;
    }
    
    public int getDigit() {
        return digit;
    }

    public Node getNext() {
        return next;
    }
    
    @Override
    // This method returns either something like "[7]" or "[7]->"
    public String toString() {
        String s = "[" + digit + "]";
        if (next == null) {
            return s;
        } else {
            return s + "->";
        }
    }
    
}
