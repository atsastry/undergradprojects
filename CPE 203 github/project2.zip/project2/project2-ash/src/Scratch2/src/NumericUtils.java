
public class NumericUtils {

    // Given a number represented as a String such as "4567",
    // return the linked list of LinkedLists, starting with the digit in the units place
    // Eg [7] -> [6] ->[5] -> [4]
    public static Node getLinkedListFromNumber(String numericString) {
        
        // Set up the first LinkedList
        char firstChar = numericString.charAt(0);
        int num = Character.getNumericValue(firstChar);
        Node currentLinkedList = new Node(num, null);

        // Then iterate thru the rest of string one character at a time
        for (int index = 1; index < numericString.length(); index++) {
            int nextNum = Character.getNumericValue(numericString.charAt(index));
            Node LinkedList = new Node(nextNum, currentLinkedList);
            currentLinkedList = LinkedList;
        }
        
        return currentLinkedList; // This LinkedList represents "[7]" in the above example
        
    }

    // Given a list such as [9]->[8]->[7]->[6]->[5],
    // returns a String "56789"
    public static String convertListToNumericString(Node n) {
        StringBuilder output = new StringBuilder();
        do  {
            output.append(n.getDigit());
            n = n.getNext();
        } while (n != null);
        
        return output.reverse().toString();
    }
    
    // Given a list such as [9]->[8]->[7]->[6]->[5], 
    // and a number, returns the string at that index
    // Example, returns "9" for index "0"
    // Example, returns "6" for index "3"
    // Example, returns "0" for index "10", since the given list is not that long
    public static int getDigitAt(Node linkedList, int index) {
        
        int length = getLength(linkedList);
        
        if (index >= length) {
            return 0; // the list is not that long
        }

        for (int i = 0; i < index; i++) {
            linkedList = linkedList.getNext();
        }
        
        return linkedList.getDigit();
    }
    
    // Given a list such as [9]->[8]->[7]->[6]->[5], 
    // return its length (i.e. 5 above)
    public static int getLength(Node node) {

        int length = 0;
        do  {
            ++length;
            node = node.getNext();
        } while (node != null);
        
        return length;
    }

    public static String stripAllLeadingZeros(String sum) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sum.length(); i++) {
            char currentChar  = sum.charAt(i);
            if (currentChar == '0') {
                continue;
            }  else {
                return sum.substring(i);
            }
        }
        // every character in the input was a zero
        return "0";

    }
}
