
public class Multiplier {
    
    public static String multiply(String number1, String number2) {

        // first convert the inputs into LinkedLists
        Node list1 = NumericUtils.getLinkedListFromNumber(number1);
        Node list2 = NumericUtils.getLinkedListFromNumber(number2);

        int len2 = NumericUtils.getLength(list2);
        String[] partialResultsArray = new String[len2];
        Node current = list2;

        // iterate over list2, and extract one digit from it at a time
        // Then multiply that digit with list1, and store that partial result
        int index = 0;
        do {
            String partialResult = multiplyWithDigit(list1, current.getDigit());
            String partialResultWithTrailingZeros = addTrailingZeros(partialResult, index);
            partialResultsArray[index] = partialResultWithTrailingZeros;
            index++;
            current = current.getNext();
        } while (current != null);

        // Now add up all the array elements in partialResultsArray
        String sum = "0";
        for (int i = 0; i < partialResultsArray.length; i++) {
            sum = Adder.add(sum, partialResultsArray[i]);
        }

        // finally, remove the leading zeros that may appear in some results
        // for example, 9999 * 0 produces 0000
        String result = NumericUtils.stripAllLeadingZeros(sum);
        return result;
    }

    private static String addTrailingZeros(String partialResult, int num) {
        StringBuilder sb = new StringBuilder(partialResult);
        for (int i = 0; i < num; i++) {
            sb = sb.append("0");
        }
        return sb.toString();
    }

    private static String multiplyWithDigit(Node list1, int digit) {
        StringBuilder result = new StringBuilder();
        int carry = 0;
        Node current = list1;
        do {
            int num = (digit * current.getDigit()) + carry;
            result.append(num % 10); // for eg, 38%10 is 8
            carry = num / 10; // for eg, 38/10 is 3
            current = current.getNext();
        } while (current != null);

        if (carry != 0) {
            result.append(carry);
        }

        return result.reverse().toString();
    }

}
