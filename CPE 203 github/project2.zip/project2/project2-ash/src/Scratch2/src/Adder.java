import java.lang.invoke.StringConcatFactory;

public class Adder {
    
    public static String add(String number1, String number2) {
        
        // first convert the inputs into LinkedLists
        Node list1 = NumericUtils.getLinkedListFromNumber(number1);
        Node list2 = NumericUtils.getLinkedListFromNumber(number2);
        
        int maxLength = 0;
        if (number1.length() >= number2.length()) {
            maxLength = number1.length();
        } else {
            maxLength = number2.length();
        }
        
        StringBuilder sb = new StringBuilder();
        int carry = 0;
        for (int index = 0; index < maxLength; index++) {
            int digit1 = NumericUtils.getDigitAt(list1, index);
            int digit2 = NumericUtils.getDigitAt(list2, index);
            int partialSum = digit1 + digit2 + carry;
            
            sb.append(partialSum % 10);  // Eg 27 % 10 is 7
            carry = partialSum / 10; // Eg 27/10 = 2
        }
        
        if (carry != 0) {
            sb.append(carry);
        }
        
        String result = sb.reverse().toString();
        return NumericUtils.stripAllLeadingZeros(result);
    }
    
}
