
public class TestCases {

    public static void main(String[] args) {

        System.out.println("-------------------");
        System.out.println("-------------------");

        // Verify the sum of two Strings
        verifyAdd("15", "155", "170");
        verifyAdd("345", "565", "910");
        verifyAdd("7777", "7777", "15554");
        verifyAdd("009", "9999", "10008");
        verifyAdd("123456789", "123456789", "246913578");
        verifyAdd("000", "0000", "0");
        verifyAdd("0", "0", "0");

        System.out.println("-------------------");
        System.out.println("-------------------");

        // Verify the multiplication of two Strings
        verifyMultiply("15", "155", "2325");
        verifyMultiply("345", "565", "194925");
        verifyMultiply("7777", "7777", "60481729");
        verifyMultiply("9", "9999", "89991");
        verifyMultiply("0", "0", "0");
        verifyMultiply("0000", "000", "0");

        System.out.println("-------------------");
        System.out.println("-------------------");

        // Verify the exponentiation of two Strings
        // TODO

    }

    private static void verifyMultiply(String op1, String op2, String expectedResult) {
        String actualResult = Multiplier.multiply(op1, op2);
        if (actualResult.equals(expectedResult)) {
            System.out.println("Multiplication PASS!");
        } else {
            System.out.println("Multiplication ** FAIL **");
        }
    }

    private static void verifyAdd(String op1, String op2, String expectedResult) {
        String actualResult = Adder.add(op1, op2);
        if (actualResult.equals(expectedResult)) {
            System.out.println("Addition PASS!");
        } else {
            System.out.println("Addition ** FAIL **");
        }
    }
    
}
