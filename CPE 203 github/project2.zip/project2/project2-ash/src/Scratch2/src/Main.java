import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {

        String filename = args[0];
        System.out.println("The input file is: " + filename);
        System.out.println();

        // Read the contents of the input file into a List of Strings
        List<String> lines = Files.readAllLines(Paths.get("src/" + filename),
                Charset.defaultCharset());

        for (String line : lines) {

            if (isAddition(line)) {

                String[] operands = getOperands(line, "\\+");
                String op1 = operands[0].strip(); // remove all extraneous spaces
                String op2 = operands[1].strip(); // remove all extraneous spaces
                String result = Adder.add(op1, op2);
                System.out.println(op1 + " + " + op2 + " = " + result);

            } else if (isMultiplication(line)) {

                String[] operands = getOperands(line, "\\*");
                String op1 = operands[0].strip(); // remove all extraneous spaces
                String op2 = operands[1].strip(); // remove all extraneous spaces
                String result = Multiplier.multiply(op1, op2);
                System.out.println(op1 + " * " + op2 + " = " + result);

            } else if (isExponent(line)) {

                String[] operands = getOperands(line, "\\^");
                String op1 = operands[0].strip(); // remove all extraneous spaces
                String op2 = operands[1].strip(); // remove all extraneous spaces
                String result = Exponential.power(op1, op2);
                System.out.println(op1 + " ^ " + op2 + " = " + result);

            } else {
                throw new RuntimeException("Unexpected operation in input");
            }

        }

    }

    private static String[] getOperands(String line, String delimeter) {
        return line.split(delimeter);
    }

    private static boolean isAddition(String line) {
        return line.contains("+");
    }

    private static boolean isMultiplication(String line) {
        return line.contains("*");
    }

    private static boolean isExponent(String line) {
        return line.contains("^");
    }

}
