
public class Exponential {
    
    public static String power(String number1, String number2) {
        // TODO
        return "";
    }
    
}
