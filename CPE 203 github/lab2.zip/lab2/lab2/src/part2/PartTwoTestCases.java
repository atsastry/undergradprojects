package part2;

import org.junit.jupiter.api.Test;
import part1.Util;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * NOTE THAT THIS FILE WILL NOT COMPILE UNTIL YOU HAVE COPIED OVER YOUR
 * EMISSION, COUNTRY, AND SECTOR CLASSES TO THE part2 DIRECTORY
 */
public class PartTwoTestCases {

    /**
     * Tests the implementation of the Emission class.
     *
     * TO-DO: Examine this test case to know what you should name your public methods.
     *
     * @throws NoSuchMethodException
     */
    @Test
    public void testEmissionImplSpecifics() throws NoSuchMethodException {
        final List<String> expectedMethodNames = Arrays.asList("getCO2", "getN2O", "getCH4");

        final List<Class> expectedMethodReturns = Arrays.asList(double.class, double.class, double.class);

        final List<Class[]> expectedMethodParameters = Arrays.asList(new Class[0], new Class[0], new Class[0]);

        verifyImplSpecifics(Emission.class, expectedMethodNames, expectedMethodReturns,
                expectedMethodParameters);
    }

    /**
     * Tests the part2 implementation of the Country class.
     *
     * @throws NoSuchMethodException
     */
    @Test
    public void testCountryImplSpecifics() throws NoSuchMethodException {
        final List<String> expectedMethodNames = Arrays.asList("getName", "getEmissions", "getYearWithHighestEmissions");

        final List<Class> expectedMethodReturns = Arrays.asList(String.class, Map.class, int.class);

        final List<Class[]> expectedMethodParameters = Arrays.asList(new Class[0], new Class[0], new Class[0]);

        verifyImplSpecifics(Country.class, expectedMethodNames, expectedMethodReturns,
                expectedMethodParameters);
    }

    /**
     * Tests the part2 implementation of the Sector class.
     *
     * @throws NoSuchMethodException
     */
    @Test
    public void testSectorImplSpecifics() throws NoSuchMethodException {
        final List<String> expectedMethodNames = Arrays.asList("getName", "getEmissions", "getYearWithHighestEmissions");

        final List<Class> expectedMethodReturns = Arrays.asList(String.class, Map.class, int.class);

        final List<Class[]> expectedMethodParameters = Arrays.asList(new Class[0], new Class[0], new Class[0]);

        verifyImplSpecifics(Sector.class, expectedMethodNames, expectedMethodReturns,
                expectedMethodParameters);
    }

    private static void verifyImplSpecifics(final Class<?> clazz, final List<String> expectedMethodNames,
                                            final List<Class> expectedMethodReturns, final List<Class[]> expectedMethodParameters)
            throws NoSuchMethodException {
        assertEquals(0, clazz.getFields().length, "Unexpected number of public fields");

        final List<Method> publicMethods = Arrays.stream(clazz.getDeclaredMethods())
                .filter(m -> Modifier.isPublic(m.getModifiers())).collect(Collectors.toList());

        assertEquals(expectedMethodNames.size(), publicMethods.size(),
                "Unexpected number of public methods");

        assertTrue(expectedMethodNames.size() == expectedMethodReturns.size(),
                "Invalid test configuration");
        assertTrue(expectedMethodNames.size() == expectedMethodParameters.size(),
                "Invalid test configuration");

        for (int i = 0; i < expectedMethodNames.size(); i++) {
            Method method = clazz.getDeclaredMethod(expectedMethodNames.get(i), expectedMethodParameters.get(i));
            assertEquals(expectedMethodReturns.get(i), method.getReturnType());
        }
    }

    @Test
    public void testYearWithHighestEmissions_nonstatic() {
        // create testable country object
        Map <Integer, part2.Emission> emissions = new HashMap<>();
        part2.Emission emission = new part2.Emission(423.1, 322.1, 32.1);
        part2.Emission emission2 = new part2.Emission(231.0, 43.2, 322.1);
        part2.Emission emission3 = new part2.Emission(100002.9, 322.2, 321.3);
        emissions.put(1972, emission);
        emissions.put(2005, emission2);
        emissions.put(3433, emission3);
        part2.Country country = new part2.Country("Arya", emissions);
        assertEquals(3433, country.getYearWithHighestEmissions());
    }

    @Test
    public void testYearWithHighestEmissions_nonstatic_2() {
        // create a testable sector object
        Map <Integer, Double> emissions = new HashMap<>();
        emissions.put(1970, 2278.8);
        emissions.put(1971, 2956.43);
        emissions.put(1972, 2243.3);
        part2.Sector sector = new part2.Sector("Transport", emissions);
        assertEquals(1971, sector.getYearWithHighestEmissions());
    }

    @Test
    public void testYearWithHighestEmissions_nonstatic_3() {
        // create testable country object
        Map <Integer, part2.Emission> emissions = new HashMap<>();
        part2.Emission emission = new part2.Emission(32.1, 6543.1, 221.1);
        part2.Emission emission2 = new part2.Emission(298.5, 9.6, 713.39);
        part2.Emission emission3 = new part2.Emission(100.0, 0.0, 6.3);
        emissions.put(1972, emission);
        emissions.put(2005, emission2);
        emissions.put(3433, emission3);
        part2.Country country = new part2.Country("Arya", emissions);
        assertEquals(1972, country.getYearWithHighestEmissions());
    }

    @Test
    public void testYearWithHighestEmissions_nonstatic_4() {
        // create a testable sector object
        Map <Integer, Double> emissions = new HashMap<>();
        emissions.put(2011, 756.4);
        emissions.put(2001, 234.1);
        emissions.put(2003, 90000.8);
        part2.Sector sector = new part2.Sector("Transport", emissions);
        assertEquals(2003, sector.getYearWithHighestEmissions());
    }
}
