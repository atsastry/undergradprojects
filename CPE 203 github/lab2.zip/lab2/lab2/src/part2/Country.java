package part2;
import part2.Emission;

import java.util.List;
import java.util.Map;

public class Country {

    private String name;

    private Map<Integer, Emission> emissions;

    public Country(String name, Map emissions) {
        this.name = name;
        this.emissions = emissions;
    }

    public String getName() {
        return this.name;
    }

//    public int getYear() {
//        return this.year;
//    }

    public Map<Integer, Emission> getEmissions() {
        return this.emissions;
    }

    public int getYearWithHighestEmissions() {
        // return the year with the highest total emissions in its Map of years
        // to CO2, NO, and CH4
        double max_total = 0;
        double curr_total;
        int max_year = 0;
        for (Map.Entry<Integer, Emission> current : this.getEmissions().entrySet()) {
            curr_total = current.getValue().getCO2() + current.getValue().getN2O() + current.getValue().getCH4();
            if (curr_total > max_total) {
                max_total = curr_total;
                max_year = current.getKey();
            }
        }
        // return the year associated with the max
        return max_year;
    }

}