package part2;

import java.util.Map;

public class Sector {
    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map emissions) {
        this.name = name;
        this.emissions = emissions;
    }

    public String getName() {
        return name;
    }

//    public int getYear() {
//        return year;
//    }

    public Map<Integer, Double> getEmissions() {
        return emissions;
    }

    public int getYearWithHighestEmissions() {
        // return the year with the highest emissions in its Map of years to emissions
        double max_total = 0;
        double curr_total = 0;
        int max_year = 0;
        for (Map.Entry<Integer, Double> current : this.getEmissions().entrySet()) {
            curr_total = current.getValue();
            if (curr_total > max_total) {
                max_total = curr_total;
                max_year = current.getKey();
            }
        }
        return max_year;
    }
}


