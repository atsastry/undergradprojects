package part3;
//import part2.Emission;

import java.util.List;
import java.util.Map;

public class Country {

    private String name;

    private Map<Integer, Emission> emissions;

    public Country(String name, Map emissions) {
        this.name = name;
        this.emissions = emissions;
    }

    public String getName() {
        return this.name;
    }

//    public int getYear() {
//        return this.year;
//    }

    public Map<Integer, Emission> getEmissions() {
        return this.emissions;
    }

    public int getYearWithHighestEmissions() {
        // return the year with the highest total emissions in its Map of years
        // to CO2, NO, and CH4
        double max_total = 0;
        double curr_total;
        int max_year = 0;
        for (Map.Entry<Integer, Emission> current : this.getEmissions().entrySet()) {
            curr_total = current.getValue().getCO2() + current.getValue().getN2O() + current.getValue().getCH4();
            if (curr_total > max_total) {
                max_total = curr_total;
                max_year = current.getKey();
            }
        }
        // return the year associated with the max
        return max_year;
    }

    public static part3.Country countryWithHighestCH4inYear(List<part3.Country> countries, int year) {
        double max_methane = 0;
        part3.Country max_country = null;
        for (part3.Country country : countries) {
            for (Map.Entry<Integer, part3.Emission> emission_map : country.getEmissions().entrySet()) {
                if (emission_map.getKey() == year) {
                    if (emission_map.getValue().getCH4() > max_methane) {
                        max_methane = emission_map.getValue().getCH4();
                        max_country = country;
                    }
                }
            }
        }
        System.out.println(max_methane);
        return max_country;
    }

    public static part3.Country countrywithHighestChangeInEmissions(List<part3.Country> countries, int startYear, int endYear) {
        double total_start_yr = 0;
        double total_end_yr = 0;
        double max_diff = 0;
        double curr_diff = 0;
        part3.Country max_country = null;
        for (part3.Country country: countries) {
            for (Map.Entry<Integer, part3.Emission> emission_map : country.getEmissions().entrySet()) {
                if (emission_map.getKey() == startYear) {
                    total_start_yr = emission_map.getValue().getCO2() + emission_map.getValue().getN2O() + emission_map.getValue().getCH4();
                }
                if (emission_map.getKey() == endYear) {
                    total_end_yr = emission_map.getValue().getCO2() + emission_map.getValue().getN2O() + emission_map.getValue().getCH4();
                }
            }
            curr_diff = total_end_yr - total_start_yr;
            if (curr_diff > max_diff) {
                max_diff = curr_diff;
                max_country = country;
            }

        }
        System.out.println("The name of the country is: " + max_country.getName());
        System.out.println("The difference in total gas emissions in this two years is: " + max_diff);

        return max_country;

    }

}