package part3;

import jdk.internal.icu.util.CodePointMap;
//import part2.Emission;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.Scanner;

/**
 * NOTE THAT THIS CLASS WILL NOT COMPILE UNTIL YOU HAVE COMPLETED PART 2 OF THIS LAB
 */
public class Main {

    public Main() throws FileNotFoundException {
    }

    public static void main(String[] args) throws FileNotFoundException {
        List<Country> countries = getCountries();
        List<Sector> sectors = getSectors();

        System.out.println("#1 " + part3.Country.countryWithHighestCH4inYear(countries, 2000).getName());
        System.out.println("#2 " + part3.Country.countrywithHighestChangeInEmissions(countries, 1988, 2012).getName());
        System.out.println("#3 " + Sector.sectorWithBiggestChangeInEmissions(sectors, 1988, 2012).getName());
    }

	/**
     * Reads country emissions data from the countries.csv file. Do not modify this
     * method. Note that this method won't compile until you have implemented the
     * Country class.
     *
     * @return A List of Country objects.
     * @throws FileNotFoundException If the countries.csv file does not exist
     */
    private static List<Country> getCountries() throws FileNotFoundException {
        File dataFile = new File("countries.csv");
        Map<String, Map<Integer, Emission>> emissions = new HashMap<>();

        Scanner scan = new Scanner(dataFile);
        scan.nextLine(); // Skip the header line
        while (scan.hasNextLine()) {
            String[] data = scan.nextLine().split(",");

            // Each line contains Country, Year, CO2, N20, CH4 --- in that order
            String name = data[0];
            int year = Integer.parseInt(data[1]);
            double co2emissions = Double.parseDouble(data[2]);
            double n2oemissions = Double.parseDouble(data[3]);
            double ch4emissions = Double.parseDouble(data[4]);

            Emission emission = new Emission(co2emissions, n2oemissions, ch4emissions);

            if (!emissions.containsKey(name)) {
                emissions.put(name, new HashMap<>());
            }
            emissions.get(name).put(year, emission);
        }
        scan.close();

        // Process emissions into a List of Countries
        List<Country> result = new LinkedList<>();
        for (Map.Entry<String, Map<Integer, Emission>> entry : emissions.entrySet()) {
            Country country = new Country(entry.getKey(), entry.getValue());
            result.add(country);
        }

        return result;
    }

    /**
     * Reads sector emissions data from the sectors.csv file. Do not modify this
     * method. Note that this method won't compile until you have implemented the
     * Country class.
     *
     * @return A List of Sector objects
     * @throws FileNotFoundException If the sectors.csv file does not exist
     */
    private static List<Sector> getSectors() throws FileNotFoundException {
        File dataFile = new File("sectors.csv");
        Map<String, Map<Integer, Double>> tempMap = new HashMap<>();
        Scanner scan = new Scanner(dataFile);
        scan.nextLine(); // Skip the header line
        while (scan.hasNextLine()) {
            String[] data = scan.nextLine().split(",");

            // Each line contains Sector, Year, Emissions --- in that order
            String name = data[0].split("\\.")[2]; // Sector names are "Emissions.Sector.X" — we only want "X"
            int year = Integer.parseInt(data[1]);
            double greenhouseGasEmissions = Double.parseDouble(data[2]);

            if (!tempMap.containsKey(name)) {
                tempMap.put(name, new HashMap<>());
            }
            tempMap.get(name).put(year, greenhouseGasEmissions);
        }
        scan.close();

        // Process tempMap into a List of Countries
        List<Sector> result = new LinkedList<>();
        for (Map.Entry<String, Map<Integer, Double>> entry : tempMap.entrySet()) {
            Sector sector = new Sector(entry.getKey(), entry.getValue());
            result.add(sector);
        }

        return result;
    }

//    public static Country countryWithHighestCH4inYear(List<Country> countries, int year) {
//        double max_methane = 0;
//        Country max_country = null;
//        for (Country country : countries) {
//            for (Map.Entry<Integer, part2.Emission> emission_map : country.getEmissions().entrySet()) {
//                if (emission_map.getKey() == year) {
//                    if (emission_map.getValue().getCH4() > max_methane) {
//                        max_methane = emission_map.getValue().getCH4();
//                        max_country = country;
//                    }
//                }
//            }
//        }
//        System.out.println(max_methane);
//        return max_country;
//    }
//
//    public static Country countrywithHighestChangeInEmissions(List<Country> countries, int startYear, int endYear) {
//        double total_start_yr = 0;
//        double total_end_yr = 0;
//        double max_diff = 0;
//        double curr_diff = 0;
//        Country max_country = null;
//        for (Country country: countries) {
//            for (Map.Entry<Integer, part2.Emission> emission_map : country.getEmissions().entrySet()) {
//                if (emission_map.getKey() == startYear) {
//                    total_start_yr = emission_map.getValue().getCO2() + emission_map.getValue().getN2O() + emission_map.getValue().getCH4();
//                }
//                if (emission_map.getKey() == endYear) {
//                    total_end_yr = emission_map.getValue().getCO2() + emission_map.getValue().getN2O() + emission_map.getValue().getCH4();
//                }
//            }
//            curr_diff = total_end_yr - total_start_yr;
//            if (curr_diff > max_diff) {
//                max_diff = curr_diff;
//                max_country = country;
//            }
//
//        }
//        System.out.println("The name of the country is: " + max_country.getName());
//        System.out.println("The difference in total gas emissions in this two years is: " + max_diff);
//
//        return max_country;
//
//    }

//    public static Sector sectorWithBiggestChangeInEmissions(List<Sector> sectors, int startYear, int endYear) {
//        double max_val = 0;
//        Sector max_sector = null;
//        for (Sector curr_sector : sectors) {
//            double total_endYear = curr_sector.getEmissions().get(endYear);
//            double total_startYear = curr_sector.getEmissions().get(startYear);
//            double difference = total_endYear - total_startYear;
//            if (difference > max_val) {
//                max_val = difference;
//                max_sector = curr_sector;
//            }
//        }
//
//        System.out.println("Name of the sector is: " + max_sector.getName());
//        System.out.println("The highest value value is: " + max_val);
//        return max_sector;
//    }

}
