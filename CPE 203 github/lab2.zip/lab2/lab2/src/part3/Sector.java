package part3;

import java.util.List;
import java.util.Map;

public class Sector {
    private String name;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map emissions) {
        this.name = name;
        this.emissions = emissions;
    }

    public String getName() {
        return name;
    }

//    public int getYear() {
//        return year;
//    }

    public Map<Integer, Double> getEmissions() {
        return emissions;
    }

    public int getYearWithHighestEmissions() {
        // return the year with the highest emissions in its Map of years to emissions
        double max_total = 0;
        double curr_total = 0;
        int max_year = 0;
        for (Map.Entry<Integer, Double> current : this.getEmissions().entrySet()) {
            curr_total = current.getValue();
            if (curr_total > max_total) {
                max_total = curr_total;
                max_year = current.getKey();
            }
        }
        return max_year;
    }

    public static Sector sectorWithBiggestChangeInEmissions(List<part3.Sector> sectors, int startYear, int endYear) {
        double max_val = 0;
        Sector max_sector = null;
        for (part3.Sector curr_sector : sectors) {
            double total_endYear = curr_sector.getEmissions().get(endYear);
            double total_startYear = curr_sector.getEmissions().get(startYear);
            double difference = total_endYear - total_startYear;
            if (difference > max_val) {
                max_val = difference;
                max_sector = curr_sector;
            }
        }

        System.out.println("Name of the sector is: " + max_sector.getName());
        System.out.println("The highest value value is: " + max_val);
        return max_sector;
    }
}


