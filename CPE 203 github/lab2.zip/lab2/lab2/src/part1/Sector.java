package part1;

import java.util.Map;

public class Sector {
    private String name;
//    private int year;
    private Map<Integer, Double> emissions;

    public Sector(String name, Map emissions) {
        this.name = name;
        this.emissions = emissions;
    }

    public String getName() {
        return name;
    }


    public Map<Integer, Double> getEmissions() {
        return emissions;
    }
}

