package part1;
import java.util.Map;

public class Util {
    public static int getYearWithHighestEmissions(Country country) {
        // return the year with the highest total emissions in its Map of years
        // to CO2, NO, and CH4
        double max_total = 0;
        double curr_total;
        int max_year = 0;
        for (Map.Entry<Integer, Emission> current : country.getEmissions().entrySet()) {
            curr_total = current.getValue().getCO2() + current.getValue().getN2O() + current.getValue().getCH4();
            if (curr_total > max_total) {
                max_total = curr_total;
                max_year = current.getKey();
            }
        }
        // return the year associated with the max
        return max_year;
    }

    public static int getYearWithHighestEmissions(Sector sector) {
        // return the year with the highest emissions in its Map of years to emissions
        double max_total = 0;
        double curr_total = 0;
        int max_year = 0;
        for (Map.Entry<Integer, Double> current : sector.getEmissions().entrySet()) {
            curr_total = current.getValue();
            if (curr_total > max_total) {
                max_total = curr_total;
                max_year = current.getKey();
            }
        }
        return max_year;
    }
}
