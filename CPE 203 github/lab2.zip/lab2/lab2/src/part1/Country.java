package part1;

import java.util.Map;

public class Country {

    private String name;
//    private int year;

    private Map<Integer, Emission> emissions;

    public Country(String name, Map emissions) {
        this.name = name;
        this.emissions = emissions;
    }

    public String getName() {
        return this.name;
    }

//    public int getYear() {
//        return this.year;
//    }

    public Map<Integer, Emission> getEmissions() {
        return this.emissions;
    }
}