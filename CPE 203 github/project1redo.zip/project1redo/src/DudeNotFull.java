import processing.core.PImage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class DudeNotFull extends DudeCommon implements MoreEntity, Transformable, ActionEntity, Movable{
    public static final int DUDE_LIMIT = 2;
    public static final int DUDE_NUM_PROPERTIES = 3;
    public static final String DUDE_KEY = "dude";
//    private final int health;

    public DudeNotFull(String id, Point position, List<PImage> images, int imageIndex, int resourceLimit, int resourceCount, int actionPeriod, int animationPeriod) {
        super(id, position, images, imageIndex, resourceLimit, resourceCount, actionPeriod, animationPeriod);
//        this.health = health;
    }


    public static DudeNotFull createDudeNotFull(String id, Point position, List<PImage> images, int resourceLimit, double actionPeriod, double animationPeriod) {
        return new DudeNotFull(id, position, images, 0, resourceLimit, 0, DUDE_ACTION_PERIOD, DUDE_ANIMATION_PERIOD);
    }


    @Override
    public double getAnimationPeriod() {
        return DUDE_ANIMATION_PERIOD;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), DUDE_ACTION_PERIOD);
        scheduler.scheduleEvent(this, Animation.createAnimationAction(0), this.getAnimationPeriod());
    }

    public void executeDudeNotFullActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> target = this.position.findNearest(world, new ArrayList<>(Arrays.asList(Tree.class, Sapling.class)));

        if (target.isEmpty() || !this.moveTo(world, target.get(), scheduler) || !this.transform(world, scheduler, imageStore)) {
            scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), DUDE_ACTION_PERIOD);
        }
    }


    @Override
    public void executeActivityAction(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.executeDudeNotFullActivity(world, imageStore, scheduler);

    }

    @Override
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        if (this.resourceCount >= this.resourceLimit) {
            Entity dude = DudeFull.createDudeFull(this.id, this.position, this.resourceLimit, this.images);

            world.removeEntity(scheduler, this);
            scheduler.unscheduleAllEvents(this);

            world.addEntity(dude);
            this.scheduleActions(scheduler, world, imageStore);

            return true;
        }

        return false;
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) { // move to not full originally
        if (this.position.adjacent(target.position)) {
            this.resourceCount += 1;
//            target.health--;
            return true;
        } else {
            Point nextPos = this.nextPositionDude(this, world, target.position);

            if (!this.position.equals(nextPos)) {
                world.moveEntity(scheduler, this, nextPos);
            }
            return false;
        }
    }
}
