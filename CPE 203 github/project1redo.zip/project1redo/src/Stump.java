import processing.core.PImage;

import java.util.List;

public class Stump extends Entity{
    public static final int STUMP_NUM_PROPERTIES = 0;
    public static final String STUMP_KEY = "stump";

    public Stump(String id, Point position, List<PImage> images, int imageIndex) {
        super(id, position, images, imageIndex);
    }


    public static Stump createStump(String id, Point position, List<PImage> images) {
        return new Stump(id, position, images, 0);
    }

//    public static void parseStump(WorldModel world, String[] properties, Point pt, String id, ImageStore imageStore) {
//        if (properties.length == STUMP_NUM_PROPERTIES) {
//            Entity entity = createStump(id, pt, imageStore.getImageList(STUMP_KEY));
//            this.tryAddEntity(entity);
//        }else{
//            throw new IllegalArgumentException(String.format("%s requires %d properties when parsing", STUMP_KEY, STUMP_NUM_PROPERTIES));
//        }
//    }

}
