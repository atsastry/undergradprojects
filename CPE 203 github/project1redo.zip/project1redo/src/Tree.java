import processing.core.PImage;

import java.util.List;

public class Tree extends Entity implements ActionEntity, Transformable, MoreEntity{
    public static final int TREE_ANIMATION_PERIOD = 0; // used in parseTree
    public static final int TREE_ACTION_PERIOD = 1; // used in parseTree
    public static final int TREE_HEALTH = 2; // used in parseTree
    public static final int TREE_NUM_PROPERTIES = 3; // used in parseTree

    public static final String TREE_KEY = "tree";

    public final int health;

//    private final int healthLimit;


    public Tree(String id, Point position, List<PImage> images, int imageIndex, int actionPeriod, int animationPeriod, int health) {
        super(id, position, images, imageIndex);
        this.health = health;
//        this.healthLimit = healthLimit;
    }

    @Override
    public void executeActivityAction(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.executeTreeActivity(world, imageStore, scheduler);

    }


    @Override
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) { //transform tree
        if (this.health <= 0) {
            Entity stump = Stump.createStump(Stump.STUMP_KEY + "_" + this.id, this.position, imageStore.getImageList(Stump.STUMP_KEY));

            world.removeEntity(scheduler, this);

            world.addEntity(stump);

            return true;
        }

        return false;
    }


    public static Tree createTree(String id, Point position, List<PImage> images, double actionPeriod, double animationPeriod, int health) {
        return new Tree(id, position, images, 0, TREE_ACTION_PERIOD, TREE_ANIMATION_PERIOD, health);
    }

//    public static void parseTree(String[] properties, Point pt, String id, ImageStore imageStore) {
//        if (properties.length == TREE_NUM_PROPERTIES) {
//            Entity entity = createTree(id, pt, imageStore.getImageList(TREE_KEY), Double.parseDouble(properties[TREE_ACTION_PERIOD]), Double.parseDouble(properties[TREE_ANIMATION_PERIOD]), Integer.parseInt(properties[TREE_HEALTH]));
//            this.tryAddEntity(entity);
//        }else{
//            throw new IllegalArgumentException(String.format("%s requires %d properties when parsing", TREE_KEY, TREE_NUM_PROPERTIES));
//        }
//    }

    public void executeTreeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {

        if (!this.transform(world, scheduler, imageStore)) {

            scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), TREE_ACTION_PERIOD);
        }
    }

    @Override
    public double getAnimationPeriod() {
        return TREE_ANIMATION_PERIOD;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), TREE_ACTION_PERIOD);
        scheduler.scheduleEvent(this, Animation.createAnimationAction(0), this.getAnimationPeriod());
    }
}
