/**
 * An action that can be taken by an entity
 */
abstract class Action {
//    private final Entity entity;
//    private final WorldModel world;
//    private final ImageStore imageStore;
//    private final int repeatCount;

//    public Action(ActionKind kind, Entity entity, WorldModel world, ImageStore imageStore, int repeatCount) {
//        this.kind = kind;
//        this.entity = entity;
//        this.world = world;
//        this.imageStore = imageStore;
//        this.repeatCount = repeatCount;
//    }

    public abstract void executeAction(EventScheduler scheduler); // do one of these in animation
//        switch (this.kind) {
//            case ACTIVITY:
//                this.executeActivityAction(scheduler);
//                break;
//
//            case ANIMATION:
//                this.executeAnimationAction(scheduler);
//                break;
//        }
//    }

//    public void executeActivityAction(EventScheduler scheduler) { // executeAction
//        switch (this.entity.kind) {
//            case SAPLING:
//                this.entity.executeSaplingActivity(this.world, this.imageStore, scheduler);
//                break;
//            case TREE:
//                this.entity.executeTreeActivity(this.world, this.imageStore, scheduler);
//                break;
//            case FAIRY:
//                this.entity.executeActivity(this.world, this.imageStore, scheduler); // this line goes off
//                break;
//            case DUDE_NOT_FULL:
//                this.entity.executeDudeNotFullActivity(this.world, this.imageStore, scheduler);
//                break;
//            case DUDE_FULL:
//                this.entity.executeDudeFullActivity(this.world, this.imageStore, scheduler);
//                break;
//            default:
//                throw new UnsupportedOperationException(String.format("executeActivityAction not supported for %s", this.entity.kind));
//        }
//    }
//
//    private void executeAnimationAction(EventScheduler scheduler) {
//        this.entity.nextImage();
//
//        if (this.repeatCount != 1) {
//            scheduler.scheduleEvent(this.entity, this.entity.createAnimationAction(Math.max(this.repeatCount - 1, 0)), this.entity.getAnimationPeriod());
//        }
//    }
}
