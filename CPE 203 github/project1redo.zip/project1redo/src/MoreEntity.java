public interface MoreEntity{
   public double getAnimationPeriod();

    public abstract void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore);
}
