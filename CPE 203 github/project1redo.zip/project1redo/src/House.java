import processing.core.PImage;

import java.util.List;

public class House extends Entity{
    public static final int HOUSE_NUM_PROPERTIES = 0;
    public static final String HOUSE_KEY = "house";

    public House(String id, Point position, List<PImage> images) {
        super(id, position, images, 0);
    }

    public static House createHouse(String id, Point position, List<PImage> images) {
        return new House(id, position, images);
    }

//    public void parseHouse(String[] properties, Point pt, String id, ImageStore imageStore) {
//        if (properties.length == HOUSE_NUM_PROPERTIES) {
//            Entity entity = createHouse(id, pt, imageStore.getImageList(HOUSE_KEY));
//            this.tryAddEntity(entity);
//        }else{
//            throw new IllegalArgumentException(String.format("%s requires %d properties when parsing", HOUSE_KEY, HOUSE_NUM_PROPERTIES));
//        }
//    }

}
