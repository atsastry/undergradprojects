public class Animation extends Action {
    private final int repeatCount;
    public int imageIndex;
    private Entity entity;

    public Animation(int repeatCount) {
        this.repeatCount = repeatCount;
    }

    public void executeAnimationAction(Entity entity, EventScheduler scheduler) {
        this.nextImage();
        if (this.repeatCount != 1) {
            if (entity instanceof Fairy) {
                scheduler.scheduleEvent(entity, createAnimationAction(Math.max(this.repeatCount - 1, 0)), ((Fairy)entity).getAnimationPeriod());
            }
            else if (entity instanceof DudeFull) {
                scheduler.scheduleEvent(entity, createAnimationAction(Math.max(this.repeatCount - 1, 0)), ((DudeFull)entity).getAnimationPeriod());
            }
            else if (entity instanceof DudeNotFull) {
                scheduler.scheduleEvent(entity, createAnimationAction(Math.max(this.repeatCount - 1, 0)), ((DudeNotFull)entity).getAnimationPeriod());
            }
            else if (entity instanceof Obstacle) {
                scheduler.scheduleEvent(entity, createAnimationAction(Math.max(this.repeatCount - 1, 0)), ((Obstacle)entity).getAnimationPeriod());
            }
            else if (entity instanceof Sapling) {
                scheduler.scheduleEvent(entity, createAnimationAction(Math.max(this.repeatCount - 1, 0)), ((Sapling)entity).getAnimationPeriod());
            }
            else if (entity instanceof Tree){
                scheduler.scheduleEvent(entity, createAnimationAction(Math.max(this.repeatCount - 1, 0)), ((Tree)entity).getAnimationPeriod());
            }
        }


    }


    public static Animation createAnimationAction(int repeatCount) {
        return new Animation(repeatCount);
    }

    @Override
    public void executeAction(EventScheduler scheduler) {
        this.executeAnimationAction(entity, scheduler);
    }

    public void nextImage() {
        this.imageIndex = this.imageIndex + 1;
    }
}
