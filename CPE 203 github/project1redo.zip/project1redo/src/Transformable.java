public interface Transformable { // implemented by dude not full, sapling, tree
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);
}
