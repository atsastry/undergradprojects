public class Activity extends Action{
    private ActionEntity actionEntity;
    private final WorldModel world;
    private final ImageStore imageStore;

    public Activity(ActionEntity entity, WorldModel world, ImageStore imageStore) {
        this.actionEntity = entity;
        this.world = world;
        this.imageStore = imageStore;
    }

    @Override
    public void executeAction(EventScheduler scheduler) {
        actionEntity.executeActivityAction(world, imageStore, scheduler);
    }
    public static Activity createActivityAction(ActionEntity actionEntity, WorldModel world, ImageStore imageStore) {
        return new Activity(actionEntity, world, imageStore);
    }
}
