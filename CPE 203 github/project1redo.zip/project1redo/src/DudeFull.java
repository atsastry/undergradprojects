import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DudeFull extends DudeCommon implements MoreEntity, ActionEntity, Movable{

    protected DudeFull(String id, Point position, List<PImage> images, int imageIndex, int resourceLimit, int resourceCount, int actionPeriod, int animationPeriod) {
        super(id, position, images, imageIndex, resourceLimit, resourceCount, actionPeriod, animationPeriod);
    }

    @Override
    public void executeActivityAction(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.executeDudeFullActivity(world, imageStore, scheduler);
    }

    public void executeDudeFullActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> fullTarget = this.position.findNearest(world, new ArrayList<>(List.of(House.class)));

        if (fullTarget.isPresent() && this.moveTo(world, fullTarget.get(), scheduler)) {
            this.transformFull(world, scheduler, imageStore);
        } else {
            scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), DUDE_ACTION_PERIOD);
        }
    }

    public static DudeFull createDudeFull(String id, Point position, int resourceLimit, List<PImage> images) {
        return new DudeFull(id, position, images, 0, resourceLimit, 0, DUDE_ACTION_PERIOD, DUDE_ANIMATION_PERIOD);
    }

    @Override
    public double getAnimationPeriod() {
        return DUDE_ANIMATION_PERIOD;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent( this, Activity.createActivityAction(this, world, imageStore), DUDE_ACTION_PERIOD);
        scheduler.scheduleEvent(this, Animation.createAnimationAction(0), this.getAnimationPeriod());
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (this.position.adjacent(target.position)) {
            return true;
        } else {
            Point nextPos = this.nextPositionDude(this, world, target.position);

            if (!this.position.equals(nextPos)) {
                world.moveEntity(scheduler, this, nextPos);
            }
            return false;
        }
    }

    public void transformFull(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        Entity dude = DudeNotFull.createDudeNotFull(this.id, this.position, this.images, this.resourceLimit, DUDE_ACTION_PERIOD, DUDE_ANIMATION_PERIOD);

        world.removeEntity(scheduler, this);

        world.addEntity(dude);
        scheduleActions(scheduler, world, imageStore);
    }
}
