import processing.core.PImage;

import java.util.List;

public abstract class DudeCommon extends Entity{
    public static final int DUDE_ANIMATION_PERIOD = 1;

    public static final int DUDE_ACTION_PERIOD = 2;

    public final int resourceLimit;
    public int resourceCount;

    public final int actionPeriod;

    public final int animationPeriod;


    protected DudeCommon(String id, Point position, List<PImage> images, int imageIndex, int resourceLimit, int resourceCount, int actionPeriod, int animationPeriod) {
        super(id, position, images, imageIndex);
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
    }

    public Point nextPositionDude(Entity entity, WorldModel world, Point destPos) {
        int horiz = Integer.signum(destPos.x - position.x);
        Point newPos = new Point(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos) && world.getOccupancyCell(newPos) instanceof Stump) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new Point(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos) && world.getOccupancyCell(newPos) instanceof Stump) {
                newPos = this.position;
            }
        }
        return newPos;
    }


}
