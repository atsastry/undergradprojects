import processing.core.PImage;

import java.util.List;

public class Obstacle extends Entity implements MoreEntity{
    public static final int OBSTACLE_ANIMATION_PERIOD = 0;
    public static final int OBSTACLE_NUM_PROPERTIES = 1;
    public static final String OBSTACLE_KEY = "obstacle";
    private final double animationPeriod;

    public Obstacle(String id, Point position, List<PImage> images, double animationPeriod) {
        super(id, position, images, 0);
        this.animationPeriod = animationPeriod;
    }

    public static Obstacle createObstacle(String id, Point position, List<PImage> images, double animationPeriod) {
        return new Obstacle(id, position, images, OBSTACLE_ANIMATION_PERIOD);
    }

//    private void parseObstacle(String[] properties, Point pt, String id, ImageStore imageStore) {
//        if (properties.length == OBSTACLE_NUM_PROPERTIES) {
//            Entity entity = createObstacle(id, pt, imageStore.getImageList(OBSTACLE_KEY), Integer.parseInt(properties[OBSTACLE_ANIMATION_PERIOD]));
//            this.tryAddEntity(entity);
//        }else{
//            throw new IllegalArgumentException(String.format("%s requires %d properties when parsing", OBSTACLE_KEY, OBSTACLE_NUM_PROPERTIES));
//        }
//    }

    @Override
    public double getAnimationPeriod() {
        return OBSTACLE_ANIMATION_PERIOD;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this,  Animation.createAnimationAction(0), this.getAnimationPeriod());

    }
}
