public interface Movable {
    public abstract boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler);

    //nextposition can go in here 
}
