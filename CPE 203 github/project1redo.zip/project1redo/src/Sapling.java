import processing.core.PImage;

import java.util.List;
import java.util.Random;

public class Sapling extends Entity implements ActionEntity, MoreEntity, Transformable{
    private static final int SAPLING_HEALTH_LIMIT = 5;
    private static final double SAPLING_ACTION_ANIMATION_PERIOD = 1.00;
    public static final String SAPLING_KEY = "sapling";
    public static final int SAPLING_NUM_PROPERTIES = 1;
    private final double TREE_ACTION_MAX = 1.400;
    private final double TREE_ACTION_MIN = 1.000;
    private final double TREE_ANIMATION_MAX = 0.600;
    private final double TREE_ANIMATION_MIN = 0.050;
    private final int TREE_HEALTH_MAX = 3;
    private final int TREE_HEALTH_MIN = 1;
    public static final int SAPLING_HEALTH = 0;
    private final double actionPeriod;
    private final double animationPeriod;
    public int health;
    private final int healthLimit;


    public Sapling(String id, Point position, List<PImage> images, int imageIndex, int health, int healthLimit, double actionPeriod, double animationPeriod) {
        super(id, position, images, imageIndex);
        this.health = health;
        this.healthLimit = healthLimit;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
    }

    public static Sapling createSapling(String id, Point position, List<PImage> images, int health) {
        return new Sapling(id, position, images, 0, SAPLING_HEALTH, SAPLING_HEALTH_LIMIT, SAPLING_ACTION_ANIMATION_PERIOD, SAPLING_ACTION_ANIMATION_PERIOD);
    }

    @Override
    public void executeActivityAction(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.executeSaplingActivity(world, imageStore, scheduler);
    }

    @Override
    public double getAnimationPeriod() {
        return SAPLING_ACTION_ANIMATION_PERIOD;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), SAPLING_ACTION_ANIMATION_PERIOD);
        scheduler.scheduleEvent(this, Animation.createAnimationAction(0), SAPLING_ACTION_ANIMATION_PERIOD);
    }

    public void executeSaplingActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.health++;
        if (!this.transform(world, scheduler, imageStore)) {
            scheduler.scheduleEvent(this, Activity.createActivityAction(this, world, imageStore), SAPLING_ACTION_ANIMATION_PERIOD);
        }
    }


    @Override
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) { // was transform sapling
        if (this.health <= 0) {
            Entity stump = Stump.createStump(Stump.STUMP_KEY + "_" + this.id, this.position, imageStore.getImageList(Stump.STUMP_KEY));

            world.removeEntity(scheduler, this);

            world.addEntity(stump);

            return true;
        } else if (this.health >= this.healthLimit) {
            Entity tree = Tree.createTree(Tree.TREE_KEY + "_" + this.id, this.position, imageStore.getImageList(Tree.TREE_KEY), getNumFromRange(TREE_ACTION_MAX, TREE_ACTION_MIN), getNumFromRange(TREE_ANIMATION_MAX, TREE_ANIMATION_MIN), getIntFromRange(TREE_HEALTH_MAX, TREE_HEALTH_MIN));

            world.removeEntity(scheduler, this);

            world.addEntity(tree);
//            tree.scheduleActions(scheduler, world, imageStore);
            scheduleActions(scheduler, world, imageStore);

            return true;
        }

        return false;
    }

    private int getIntFromRange(int max, int min) { // in sapling
        Random rand = new Random();
        return min + rand.nextInt(max-min);
    }

    private double getNumFromRange(double max, double min) { // in sapling
        Random rand = new Random();
        return min + rand.nextDouble() * (max - min);
    }
}
