interface ActionEntity {
        public abstract void executeActivityAction(WorldModel world, ImageStore imageStore, EventScheduler scheduler);
}
