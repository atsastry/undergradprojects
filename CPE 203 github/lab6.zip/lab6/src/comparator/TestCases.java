package comparator;

import java.util.*;

import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.*;

public class TestCases
{
   private static final Song[] songs = new Song[] {
         new Song("Decemberists", "The Mariner's Revenge Song", 2005),
         new Song("Rogue Wave", "Love's Lost Guarantee", 2005),
         new Song("Avett Brothers", "Talk on Indolence", 2006),
         new Song("Gerry Rafferty", "Baker Street", 1998),
         new Song("City and Colour", "Sleeping Sickness", 2007),
         new Song("Foo Fighters", "Baker Street", 1997),
         new Song("Queen", "Bohemian Rhapsody", 1975),
         new Song("Gerry Rafferty", "Baker Street", 1978)
      };

   @Test
   public void testArtistComparator()
   {
      ArtistComparator artistComparator = new ArtistComparator();
      Song song1 = new Song("Decemberists", "The Mariner's Revenge Song", 2005);
      Song song2 = new Song("Rogue Wave", "Love's Lost Guarantee", 2005);
      int res = artistComparator.compare(song1, song2);
      assertEquals("expected to be", -14, res);

      Song song3 = new Song("City and Colour", "Sleeping Sickness", 2007);
      int res2 = artistComparator.compare(song3, song1);
      assertEquals("expected to be", -1, res2);

      int res3= artistComparator.compare(song1, song1);
      assertEquals("expected to be", 0, res3);

      int res4 = artistComparator.compare(song2, song1);
      assertEquals("expected to be", 14, res4);
   }

   @Test
   public void testLambdaTitleComparator() {
      Comparator<Song> cmp_title = (Song song1, Song song2) -> song1.getTitle().compareTo(song2.getTitle());
      assertTrue(cmp_title.compare(songs[0], songs[1])>0);
      assertTrue(cmp_title.compare(songs[4], songs[0])<0);
      assertTrue(cmp_title.compare(songs[2], songs[2])==0);


   }

   @Test
   public void testYearExtractorComparator()
   {
      Comparator<Song> cmp_year = Comparator.comparing(Song::getYear).reversed();
      assertEquals(0, cmp_year.compare(songs[1], songs[1]));
      assertTrue(cmp_year.compare(songs[1], songs[2])>0);
      assertTrue(cmp_year.compare(songs[1], songs[3])<0);
   }

   @Test
   public void testComposedComparator()
   {
      Comparator<Song> cmp_artist = (Song song1, Song song2) -> song1.getArtist().compareTo(song2.getArtist());
      Comparator<Song> cmp_year = Comparator.comparing(Song::getYear).reversed();
      ComposedComparator composedComparator = new ComposedComparator(cmp_artist, cmp_year);
      assertTrue(composedComparator.compare(songs[3], songs[7])<0);
      assertEquals(0, composedComparator.compare(songs[3], songs[3]));
      assertTrue(composedComparator.compare(songs[1], songs[2])>0);
      ComposedComparator composedComparator1 = new ComposedComparator(cmp_year, cmp_artist);
      assertTrue(composedComparator1.compare(songs[0], songs[1])<0);



   }

   @Test
   public void testThenComparing()
   {
      //first compares by title --> if titles are the same, compares by artist
      Comparator<Song> cmp_title = (Song song1, Song song2) -> song1.getTitle().compareTo(song2.getTitle());
      Comparator<Song> cmp_title_artist = cmp_title.thenComparing((song1, song2) -> song1.getArtist().compareTo(song2.getArtist()));
      assertTrue(cmp_title_artist.compare(songs[3], songs[5])>0);
      assertTrue(cmp_title_artist.compare(songs[0], songs[7])>0);

   }

   @Test
   public void runSort()
   {
      List<Song> songList = new ArrayList<>(Arrays.asList(songs));
      List<Song> expectedList = Arrays.asList(
         new Song("Avett Brothers", "Talk on Indolence", 2006),
         new Song("City and Colour", "Sleeping Sickness", 2007),
         new Song("Decemberists", "The Mariner's Revenge Song", 2005),
         new Song("Foo Fighters", "Baker Street", 1997),
         new Song("Gerry Rafferty", "Baker Street", 1978),
         new Song("Gerry Rafferty", "Baker Street", 1998),
         new Song("Queen", "Bohemian Rhapsody", 1975),
         new Song("Rogue Wave", "Love's Lost Guarantee", 2005)
         );
//      Comparator<Song> cmp_artist = (Song song1, Song song2) -> song1.getArtist().compareTo(song2.getArtist());
//      Comparator<Song> cmp_artist_title = cmp_artist.thenComparing((song1, song2) -> song1.getTitle().compareTo(song2.getTitle()));
//      Comparator<Song> year = Comparator.comparing(Song::getYear);
//      ComposedComparator composedComparator = new ComposedComparator(cmp_artist, cmp_artist_title);

      Comparator<Song> artist = Comparator.comparing(Song :: getArtist);
      Comparator<Song> title = artist.thenComparing(Song :: getTitle);
      Comparator<Song> year = title.thenComparing(Song :: getYear);

      songList.sort(year); // pass comparator where null is

      assertEquals(songList, expectedList);
   }
}
