interface GreenhouseGasEmitter {

    // declare abstract methods
    String getName();
    double getTotalEmissionsInYear(int year);

}