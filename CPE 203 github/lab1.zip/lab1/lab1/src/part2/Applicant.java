package part2;

import part1.CourseGrade;

import java.util.List;

public class Applicant {
    private final String name;
    private final List<CourseGrade> grades;
    private int age = 0;


    public Applicant (String name, List<CourseGrade> grades) {
        this.name = name;
        this.grades = grades;
    }

//    public int getAge() {
//        return this.age;
//    }

    public String getName() {
        return this.name;
    }

    public List<CourseGrade> getGrades() {
        return grades;
    }



    public CourseGrade getGradeFor(String course) {
        if (course.equals("Intro to CS")) {
            return grades.get(0);
        }
        if (course.equals("Data Structures")) {
            return grades.get(1);
        }
        if (course.equals("Algorithms")) {
            return grades.get(2);
        }
        if (course.equals("Computer Organization")) {
            return grades.get(3);
        }
        if (course.equals("Operating Systems")) {
            return grades.get(4);
        }
        if (course.equals("Non-CS GPA")) {
            return grades.get(5);
        }
        return null;
    }
}