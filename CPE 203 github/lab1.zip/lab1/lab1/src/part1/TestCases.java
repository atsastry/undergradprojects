package part1;

import java.util.*;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class TestCases
{
   private final static double DELTA = 0.0001;

   ////////////////////////////////////////////////////////////
   //                      part1.SimpleIf Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testAnalyzeApplicant()
   {
      Assertions.assertTrue(SimpleIf.analyzeApplicant(89, 85));
   }

   @Test
   public void testAnalyzeApplicant2()
   {
      Assertions.assertFalse(SimpleIf.analyzeApplicant(15, 90));
   }

   @Test
   public void testAnalyzeApplicant3()
   {
      /* TO DO: Write one more valid test case. */

      Assertions.assertFalse(SimpleIf.analyzeApplicant(92, 99));
   }

   @Test
   public void testAnalyzeApplicant4()
   {
      Assertions.assertTrue(SimpleIf.analyzeApplicant(100, 8));
   }

   @Test
   public void testAnalyzeApplicant5()
   {
      Assertions.assertTrue(SimpleIf.analyzeApplicant(69, 50));
   }

   @Test
   public void testMaxAverage() {
      Assertions.assertEquals(SimpleIf.maxAverage(89.5, 91.2), 91.2, DELTA);
   }

   @Test
   public void testMaxAverage2() {
      Assertions.assertEquals(SimpleIf.maxAverage(60, 89), 89, DELTA);
   }

   @Test
   public void testMaxAverage3() {
      /* TO DO: Write one more valid test case. */

      Assertions.assertEquals(SimpleIf.maxAverage(89.9, 90), 90, DELTA);
   }

   @Test
   public void testMaxAverage4() {
      Assertions.assertEquals(SimpleIf.maxAverage(80, 10), 80, DELTA);
   }

   @Test
   public void testMaxAverage5() {
      Assertions.assertEquals(SimpleIf.maxAverage(70, 25), 70, DELTA);
   }

   ////////////////////////////////////////////////////////////
   //                    part1.SimpleLoop Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testSimpleLoop1()
   {
      Assertions.assertEquals(7, SimpleLoop.sum(3, 4));
   }

   @Test
   public void testSimpleLoop2()
   {
      Assertions.assertEquals(7, SimpleLoop.sum(-2, 4));
   }

   @Test
   public void testSimpleLoop3()
   {
      /* TO DO: Write one more valid test case to make sure that
         this function is not just returning 7. */

      Assertions.assertEquals(10, SimpleLoop.sum(1, 4));
   }

   @Test
   public void testSimpleLoop4()
   {

      Assertions.assertEquals(28, SimpleLoop.sum(1, 7));
   }

   @Test
   public void testSimpleLoop5()
   {

      Assertions.assertEquals(1, SimpleLoop.sum(0, 1));
   }

   ////////////////////////////////////////////////////////////
   //                    part1.SimpleArray Tests                   //
   ////////////////////////////////////////////////////////////

   @Test
   public void testSimpleArray1()
   {
      /* What is that parameter?  They are newly allocated arrays
         with initial values. */
      Assertions.assertArrayEquals(
         new boolean[] {false, false, true, true, false, false},
         SimpleArray.applicantAcceptable(new int[] {80, 85, 89, 92, 76, 81}, 85)
      );
   }

   @Test
   public void testSimpleArray2()
   {
      Assertions.assertArrayEquals(
         new boolean[] {false, false},
         SimpleArray.applicantAcceptable(new int[] {80, 83}, 92));
   }

   @Test
   public void testSimpleArray3()
   {
      /* TO DO: Add a new test case. */

      Assertions.assertArrayEquals(
           new boolean[] {false, false, false, true, true, false},
              SimpleArray.applicantAcceptable(new int[] {82, 83, 84, 85, 90, 75}, 84)
      );
   }

   @Test
   public void testSimpleArray4()
   {

      Assertions.assertArrayEquals(
              new boolean[] {true, true, true, true, true, true, false},
              SimpleArray.applicantAcceptable(new int[] {10, 20, 30, 40, 50, 60, 1}, 5)
      );
   }

   @Test
   public void testSimpleArray5()
   {

      Assertions.assertArrayEquals(
              new boolean[] {true},
              SimpleArray.applicantAcceptable(new int[] {80}, 75)
      );
   }

   ////////////////////////////////////////////////////////////
   //                    part1.SimpleList Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testSimpleList1()
   {
      List<Integer> input =
         new LinkedList<>(Arrays.asList(80, 85, 89, 92, 76, 81));
      List<Boolean> expected =
         new ArrayList<>(Arrays.asList(false, false, true, true, false, false));

      Assertions.assertEquals(expected, SimpleList.applicantAcceptable(input, 85));
   }

   @Test
   public void testSimpleList2()
   {
      List<Boolean> expected = Arrays.asList(false, false, true, true, false, false);

      /* TO DO: Add a new test case. */
      List<Integer> input = Arrays.asList(80, 85, 89, 92, 76, 81);
      Assertions.assertEquals(expected, SimpleList.applicantAcceptable(input, 88));
   }

   @Test
   public void testSimpleList3()
   {
      List<Boolean> expected = Arrays.asList(true, true, false, false, false);

      List<Integer> input = Arrays.asList(80, 85, 10, 2, 49);
      Assertions.assertEquals(expected, SimpleList.applicantAcceptable(input, 50));
   }

   @Test
   public void testSimpleList4()
   {
      List<Boolean> expected = Arrays.asList(true, true, false, false, true);

      List<Integer> input = Arrays.asList(80, 85, 10, 2, 60);
      Assertions.assertEquals(expected, SimpleList.applicantAcceptable(input, 50));
   }

   ////////////////////////////////////////////////////////////
   //                    part1.BetterLoop Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testFourOver85()
   {
      Assertions.assertFalse(BetterLoop.atLeastFourOver85(new int[] {89, 93, 100, 39, 84, 63}));
   }

   @Test
   public void testFourOver85_2()
   {
      Assertions.assertTrue(BetterLoop.atLeastFourOver85(new int[] {89, 86, 90, 92, 84, 88}));
   }

   @Test
   public void testFourOver85_3()
   {
      /* TO DO: Write a valid test case where the expected result is false. */
      Assertions.assertFalse(BetterLoop.atLeastFourOver85(new int[] {85, 80, 85, 75, 80, 92}));
   }

   @Test
   public void testFourOver85_4()
   {
      Assertions.assertFalse(BetterLoop.atLeastFourOver85(new int[] {1, 2, 3, 4, 80, 92}));
   }

   @Test
   public void testFourOver85_5()
   {
      Assertions.assertTrue(BetterLoop.atLeastFourOver85(new int[] {87, 90, 95, 86, 1, 2}));
   }

//   @Test
//   public void testFourOver85_6()
//   {
//      assertEquals(part1.BetterLoop.average(new int[] {1, 2, 3, 4, 80, 92}));
//   }

   ////////////////////////////////////////////////////////////
   //                    part1.ExampleMap Tests                    //
   ////////////////////////////////////////////////////////////

   @Test
   public void testExampleMap1()
   {
      Map<String, List<CourseGrade>> courseListsByStudent = new HashMap<>();
      courseListsByStudent.put("Julie",
         Arrays.asList(
            new CourseGrade("CPE 123", 89),
            new CourseGrade("CPE 101", 90),
            new CourseGrade("CPE 202", 99),
            new CourseGrade("CPE 203", 100),
            new CourseGrade("CPE 225", 89)));
      courseListsByStudent.put("Paul",
         Arrays.asList(
            new CourseGrade("CPE 101", 86),
            new CourseGrade("CPE 202", 80),
            new CourseGrade("CPE 203", 76),
            new CourseGrade("CPE 225", 80)));
      courseListsByStudent.put("Zoe",
         Arrays.asList(
            new CourseGrade("CPE 123", 99),
            new CourseGrade("CPE 203", 91),
            new CourseGrade("CPE 471", 86),
            new CourseGrade("CPE 473", 90),
            new CourseGrade("CPE 476", 99),
            new CourseGrade("CPE 572", 100)));

      List<String> expected = Arrays.asList("Julie", "Zoe");

      /*
       * Why compare HashSets here?  Just so that the order of the
       * elements in the list is not important for this test.
       */
      Assertions.assertEquals(new HashSet<>(expected),
         new HashSet<>(ExampleMap.highScoringStudents(
            courseListsByStudent, 85)));
   }

   @Test
   public void testExampleMap2()
   {
      /* TO DO: Write another valid test case. */

      Map<String, List<CourseGrade>> courseListsByStudent = new HashMap<>();
      courseListsByStudent.put("Julie",
              Arrays.asList(
                      new CourseGrade("CPE 123", 90),
                      new CourseGrade("CPE 101", 91),
                      new CourseGrade("CPE 202", 92),
                      new CourseGrade("CPE 203", 100),
                      new CourseGrade("CPE 225", 89)));
      courseListsByStudent.put("Paul",
              Arrays.asList(
                      new CourseGrade("CPE 101", 87),
                      new CourseGrade("CPE 202", 90),
                      new CourseGrade("CPE 203", 91),
                      new CourseGrade("CPE 225", 100)));
      courseListsByStudent.put("Zoe",
              Arrays.asList(
                      new CourseGrade("CPE 123", 100),
                      new CourseGrade("CPE 203", 92),
                      new CourseGrade("CPE 471", 85),
                      new CourseGrade("CPE 473", 100),
                      new CourseGrade("CPE 476", 90),
                      new CourseGrade("CPE 572", 91)));

      List<String> expected = Arrays.asList("Julie", "Paul");


      /*
       * Why compare HashSets here?  Just so that the order of the
       * elements in the list is not important for this test.
       */
      Assertions.assertEquals(new HashSet<>(expected),
              new HashSet<>(ExampleMap.highScoringStudents(
                      courseListsByStudent, 86)));
   }
}
