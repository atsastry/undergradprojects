package calculator;

class InvalidNumberException
   extends ScannerException
{
}
