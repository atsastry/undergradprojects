package equality;

import java.util.List;
import java.util.Objects;

class Student
{
   private final String surname;
   private final String givenName;
   private final int age;
   private final List<CourseSection> currentCourses;

   public Student(final String surname, final String givenName, final int age,
      final List<CourseSection> currentCourses)
   {
      this.surname = surname;
      this.givenName = givenName;
      this.age = age;
      this.currentCourses = currentCourses;
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) return true;
      if (object == null || getClass() != object.getClass()) return false;
      Student that = (Student) object;
      if (Objects.equals(surname, null) || Objects.equals(givenName, null) ||
              Objects.equals(age, 0) || Objects.equals(currentCourses, null)) {
         return false;
      }
      return age == that.age && this.surname.equals(that.surname) && this.givenName.equals(that.givenName)
              && this.currentCourses.equals(that.currentCourses);
   }

   @Override
   public int hashCode() {
      return Objects.hash(surname, givenName, age, currentCourses);
   }
}
