package equality;

import java.time.LocalTime;
import java.util.Objects;

class CourseSection {
   private final String prefix;
   private final String number;
   private final int enrollment;
   private final LocalTime startTime;
   private final LocalTime endTime;

   public CourseSection(final String prefix, final String number,
                        final int enrollment, final LocalTime startTime, final LocalTime endTime) {
      this.prefix = prefix;
      this.number = number;
      this.enrollment = enrollment;
      this.startTime = startTime;
      this.endTime = endTime;
   }


   @Override
   public boolean equals(Object object) {
      if (this == object) return true;
      if (object == null || getClass() != object.getClass()) return false;
      CourseSection courseSection = (CourseSection) object;
      if (enrollment == 0 || prefix == null || number == null ||
              startTime == null || endTime == null) {
         return false;
      }
      if (courseSection.enrollment == 0 || courseSection.prefix == null ||
              courseSection.number == null || courseSection.startTime == null ||
              courseSection.endTime == null) {
         return false;
      }
         return enrollment == courseSection.enrollment && prefix.equals(courseSection.prefix) &&
                 number.equals(courseSection.number) && startTime.equals(courseSection.startTime) &&
                 endTime.equals(courseSection.endTime);
      }


   @Override
   public int hashCode() {
      // check for null values and then call .hashCode() on each object
      int hash = 0;
      if (this.prefix != null) {
         hash += this.prefix.hashCode();
      }
      hash *= 31;
      if (this.number != null) {
         hash += this.number.hashCode();
      }
      hash *= 31;
      hash += this.enrollment;
      hash *= 31;
      if (this.startTime != null) {
         hash += this.startTime.hashCode();
      }
      hash *= 31;
      if (this.endTime != null) {
         hash += this.endTime.hashCode();
      }
      hash *= 31;
      return hash;
   }

      // additional likely methods not defined since they are not needed for testing
   }

