package equality;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalTime;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

public class TestCases
{
   @Test
   public void testExercise1()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));
      final CourseSection two = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));

      assertTrue(one.equals(two));
      assertTrue(two.equals(one));
   }

   @Test
   public void testExercise2()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 10), LocalTime.of(10, 0));
      final CourseSection two = new CourseSection("CSC", "203", 35,
         LocalTime.of(1, 10), LocalTime.of(2, 0));

      assertFalse(one.equals(two));
      assertFalse(two.equals(one));
   }

   @Test
   public void testExercise3()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));
      final CourseSection two = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 40), LocalTime.of(11, 0));

      assertEquals(one.hashCode(), two.hashCode());
   }

   @Test
   public void testExercise4()
   {
      final CourseSection one = new CourseSection("CSC", "203", 35,
         LocalTime.of(9, 10), LocalTime.of(10, 0));
      final CourseSection two = new CourseSection("CSC", "203", 34,
         LocalTime.of(9, 10), LocalTime.of(10, 0));

      assertNotEquals(one.hashCode(), two.hashCode());
   }

   @Test
   public void testExercise5()
   {
      List<CourseSection> courses1 = new LinkedList<>();
      List<CourseSection> courses2 = new LinkedList<>();

      courses1.add(new CourseSection("CSC", "203", 35,
              LocalTime.of(9, 10), LocalTime.of(10, 0)));
      courses2.add(new CourseSection("CSC", "203", 34,
              LocalTime.of(9, 10), LocalTime.of(10, 0)));

      final Student one = new Student("sastry", "arya", 19, courses1);
      final Student two = new Student("sastry", "manny", 20, courses2);

      assertNotEquals(one.hashCode(), two.hashCode());
   }

//   @Test
//   public void testExercise6()
//   {
//      final Student one = new Student("sastry", "arya", 19, );
//      final Student two = new Student("sastry", "arya", 19, );
//
//      assertTrue(one.equals(two));
//      assertTrue(two.equals(one));
//   }
}
