import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Fairy extends Entity implements Movable, Animatable, ActivityAction {
    private double actionPeriod;
    private double animationPeriod;
    private PathingStrategy strategy;
    private double STUN_TIME = 3.0;
    private double stunStart = -STUN_TIME;


    public Fairy(String id, MyPoint position, List<PImage> images, double actionPeriod, double animationPeriod) {
        super(id, position, images);
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
        this.strategy = new AStarPathingStrategy();
    }

    public static Entity createFairy(String id, MyPoint position, double actionPeriod, double animationPeriod, List<PImage> images) {
        return new Fairy(id, position, images, actionPeriod, animationPeriod);
    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    public double getActionPeriod() {
        return this.actionPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> fairyTarget = this.position.findNearest(world, new ArrayList<>(List.of(Stump.class)));
        if (scheduler.currentTime - stunStart > STUN_TIME) {
            if (fairyTarget.isPresent()) {
                MyPoint tgtPos = fairyTarget.get().position;

                if (neighbors(this.position, tgtPos)) {
                    world.removeEntity(scheduler, fairyTarget.get());
                    Sapling sapling = Sapling.createSapling(Sapling.SAPLING_KEY + "_" + fairyTarget.get().id, tgtPos, imageStore.getImageList(Sapling.SAPLING_KEY), 0);
                    world.addEntity(sapling);
                    sapling.scheduleActions(scheduler, world, imageStore);
                } else {
                    List<MyPoint> points = strategy.computePath(this.position, fairyTarget.get().position,
                            p ->  world.withinBounds(p) && world.getOccupancyCell(p) == null ||
                                    world.withinBounds(p) && world.getOccupancyCell(p) instanceof Stump,
                            (p1, p2) -> neighbors(p1,p2),
                            PathingStrategy.CARDINAL_NEIGHBORS);
                    if (!points.isEmpty()) {
                        world.moveEntity(scheduler, this, points.get(0));
                    }
                }
            }
        }
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
    }


    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (this.position.adjacent(target.position)) {
            world.removeEntity(scheduler, target);
            return true;
        } else {
            MyPoint nextPos = this.nextPosition(world, target.position);

            if (!this.position.equals(nextPos)) {
                world.moveEntity(scheduler, this, nextPos);
            }
            return false;
        }
    }

    @Override
    public MyPoint nextPosition(WorldModel world, MyPoint destPos) {
        int horiz = Integer.signum(destPos.x - this.position.x);
        MyPoint newPos = new MyPoint(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos)) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new MyPoint(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos)) {
                newPos = this.position;
            }
        }

        return newPos;
    }

    public void stun(double stunStart) {
        this.stunStart = stunStart;
    }
}
