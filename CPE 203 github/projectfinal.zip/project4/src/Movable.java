public interface Movable { // fairy and the dudes should implement this
    public abstract boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler);

    public abstract MyPoint nextPosition(WorldModel world, MyPoint destPos);

    default boolean neighbors(MyPoint p1, MyPoint p2) {
        return p1.x+1 == p2.x && p1.y == p2.y ||
                p1.x-1 == p2.x && p1.y == p2.y ||
                p1.x == p2.x && p1.y+1 == p2.y ||
                p1.x == p2.x && p1.y-1 == p2.y;
    }


}
