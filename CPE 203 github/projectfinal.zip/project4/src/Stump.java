import processing.core.PImage;

import java.util.List;

public class Stump extends Entity{

    public Stump(String id, MyPoint position, List<PImage> images) {
        super(id, position, images);
    }

    public static Stump createStump(String id, MyPoint position, List<PImage> images) {
        return new Stump(id, position, images);
    }
}
