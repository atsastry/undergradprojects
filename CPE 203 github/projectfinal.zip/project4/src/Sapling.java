import processing.core.PImage;

import java.util.List;
import java.util.Random;

public class Sapling extends Plant implements Transformable, Animatable, ActivityAction{
    public static final String SAPLING_KEY = "sapling"; // put in sapling class but make it public ??
    private final double TREE_ACTION_MAX = 1.400; // transform sapling
    private final double TREE_ACTION_MIN = 1.000; //transform sapling
    private final int TREE_HEALTH_MAX = 3; // transform sapling
    private final int TREE_HEALTH_MIN = 1; // transform sapling
    private final double TREE_ANIMATION_MAX = 0.600; // transform sapling
    private final double TREE_ANIMATION_MIN = 0.050; // transform sapling
    private static final double SAPLING_ACTION_ANIMATION_PERIOD = 1.000; // have to be in sync since grows and gains health at same time
    private static final int SAPLING_HEALTH_LIMIT = 5;
    private double actionPeriod; //executesapling, executetree, executefairy, executedudefull, executedudenotfull
    private double animationPeriod; // sapling, tree, fairy, dudefull, dudenotfull, obstacle
    private int healthLimit; //transform sapling

    public Sapling(String id, MyPoint position, List<PImage> images, int imageIndex, int health, int healthLimit, double actionPeriod, double animationPeriod) {
        super(id, position, images, health);
        this.healthLimit = healthLimit;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
    }

    public static Sapling createSapling(String id, MyPoint position, List<PImage> images, int health) {
        return new Sapling(id, position, images, 0, 0, SAPLING_HEALTH_LIMIT, SAPLING_ACTION_ANIMATION_PERIOD, SAPLING_ACTION_ANIMATION_PERIOD);
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        this.health++;
        if (!this.transform(world, scheduler, imageStore)) {
            scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        }
    }

    @Override
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        if (this.health <= 0) {
            Entity stump = Stump.createStump(STUMP_KEY + "_" + this.id, this.position, imageStore.getImageList(STUMP_KEY));

            world.removeEntity(scheduler, this);

            world.addEntity(stump);

            return true;
        } else if (this.health >= this.healthLimit) {
            Tree tree = Tree.createTree(WorldModel.TREE_KEY + "_" + this.id, this.position, imageStore.getImageList(WorldModel.TREE_KEY), getNumFromRange(TREE_ACTION_MAX, TREE_ACTION_MIN), getNumFromRange(TREE_ANIMATION_MAX, TREE_ANIMATION_MIN), getIntFromRange(TREE_HEALTH_MAX, TREE_HEALTH_MIN));

            world.removeEntity(scheduler, this);

            world.addEntity(tree);
            tree.scheduleActions(scheduler, world, imageStore);
            return true;
        }

        return false;
    }

    private int getIntFromRange(int max, int min) {
        Random rand = new Random();
        return min + rand.nextInt(max-min);
    }

    private double getNumFromRange(double max, double min) {
        Random rand = new Random();
        return min + rand.nextDouble() * (max - min);
    }


    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }
}




















