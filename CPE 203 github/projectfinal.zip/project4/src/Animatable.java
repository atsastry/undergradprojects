public interface Animatable { // sapling, tree, fairy, dudefull, dudenotfull, obstacle
        public double getAnimationPeriod();

        public abstract void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore);
}
