public class Animation extends Action{
    public Animation(Entity entity, int repeatCount) {
        super(entity, null, null, repeatCount);
    }

    @Override
    public void executeAction(EventScheduler eventScheduler) {
        this.executeAnimationAction(eventScheduler);
    }

    private void executeAnimationAction(EventScheduler scheduler) {
        this.entity.nextImage();

        if (this.repeatCount != 1) {
            scheduler.scheduleEvent(this.entity, new Animation(this.entity, Math.max(this.repeatCount - 1, 0)), ((Animatable)this.entity).getAnimationPeriod());
        }
    }
}
