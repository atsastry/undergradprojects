import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Monster extends Entity implements Animatable, Movable, ActivityAction{
    public static final double DEFAULT_ACTION_PERIOD = 0.784;
    public static final double DEFAULT_ANIMATION_PERIOD = 0.180;

    private double actionPeriod;
    private double animationPeriod;
    private PathingStrategy pathingStrategy;

    public Monster(String id, MyPoint position, List<PImage> images, double actionPeriod, double animationPeriod) {
        super(id, position, images);
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
        this.pathingStrategy = new AStarPathingStrategy();
//        System.out.println(images);
    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> monsterTarget = this.position.findNearest(world, new ArrayList<>(List.of(BlueLadybug.class, Fairy.class)));
        if (monsterTarget.isPresent()) {
            if (moveTo(world, monsterTarget.get(), scheduler)) {
                MyPoint tgtPos = monsterTarget.get().position;
                world.removeEntity(scheduler, monsterTarget.get());
                DudeNotFull dude = new DudeNotFull(monsterTarget.get().id, tgtPos, imageStore.getImageList(world.DUDE_KEY), 3, 0, 0.784, 0.180);
                world.addEntity(dude);
                dude.scheduleActions(scheduler, world, imageStore);
                world.removeEntity(scheduler, this);
                return;
            }
        }
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        MyPoint tgtPos = target.position;
        if (neighbors(this.position, tgtPos)) {
            return true;
        }
        List<MyPoint> points = pathingStrategy.computePath(this.position, tgtPos,
                p ->  world.withinBounds(p) && world.getOccupancyCell(p) == null ||
                        world.withinBounds(p) && world.getOccupancyCell(p) instanceof Stump,
                (p1, p2) -> neighbors(p1,p2),
                PathingStrategy.CARDINAL_NEIGHBORS);
        if (!points.isEmpty()) {
            world.moveEntity(scheduler, this, points.get(0));
        }
        return false;
    }

    @Override
    public MyPoint nextPosition(WorldModel world, MyPoint destPos) {
        int horiz = Integer.signum(destPos.x - this.position.x);
        MyPoint newPos = new MyPoint(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos)) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new MyPoint(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos)) {
                newPos = this.position;
            }
        }

        return newPos;
    }
}
