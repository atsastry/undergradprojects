public interface Transformable { // dudenotfull, tree, sapling, not dudefull because different return type

    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore);
}
