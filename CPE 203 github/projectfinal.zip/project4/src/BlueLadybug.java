import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BlueLadybug extends Entity implements Animatable, ActivityAction {
    private double actionPeriod;
    private double animationPeriod;
    private PathingStrategy strategy;
    private double STUN_TIME = 3.0;
    private double stunStart = -STUN_TIME;


    public BlueLadybug(String id, MyPoint position, List<PImage> images, double actionPeriod, double animationPeriod, double stunStart) {
        super(id, position, images);
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
        this.strategy = new AStarPathingStrategy();
        this.stunStart = stunStart;
    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        if (scheduler.currentTime - stunStart > STUN_TIME) {
            Fairy fairy = new Fairy(this.id, this.position, imageStore.getImageList("fairy"), this.actionPeriod, this.animationPeriod);
            world.removeEntity(scheduler, this);
            world.addEntity(fairy);
            fairy.scheduleActions(scheduler, world, imageStore);
            return;
        }
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
    }
}
