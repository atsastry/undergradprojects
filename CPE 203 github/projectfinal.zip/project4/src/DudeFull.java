import processing.core.PImage;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DudeFull extends Entity implements Movable, Animatable, ActivityAction{
    private int resourceLimit;
    private int resourceCount;
    private double actionPeriod;
    private double animationPeriod;
    private PathingStrategy strategy;

    public DudeFull(String id, MyPoint position, List<PImage> images, int resourceLimit, int resourceCount, double actionPeriod, double animationPeriod) {
        super(id, position, images);
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
        this.strategy = new AStarPathingStrategy();
    }

    public static DudeFull createDudeFull(String id, MyPoint position, double actionPeriod, double animationPeriod, int resourceLimit, List<PImage> images) {
        return new DudeFull(id, position, images, resourceLimit, 0, actionPeriod, animationPeriod);
    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (this.position.adjacent(target.position)) {
            return true;
        } else {
            MyPoint nextPos = this.nextPosition(world, target.position);

            if (!this.position.equals(nextPos)) {
                world.moveEntity(scheduler, this, nextPos);
            }
            return false;
        }
    }

    @Override
    public MyPoint nextPosition(WorldModel world, MyPoint destPos) {
        int horiz = Integer.signum(destPos.x - this.position.x);
        MyPoint newPos = new MyPoint(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos) && !(world.getOccupancyCell(newPos) instanceof Stump) ) {

            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new MyPoint(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos) && !(world.getOccupancyCell(newPos) instanceof Stump)) {
                newPos = this.position;
            }
        }

        return newPos;
    }

    public void transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        DudeNotFull dude = DudeNotFull.createDudeNotFull(this.id, this.position, this.actionPeriod, this.animationPeriod, this.resourceLimit, this.images);

        world.removeEntity(scheduler, this);

        world.addEntity(dude);
        dude.scheduleActions(scheduler, world, imageStore);
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> fullTarget = this.position.findNearest(world, new ArrayList<>(List.of(House.class)));
        if (fullTarget.isEmpty()) {
            scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
            return;
        }

        if (neighbors(this.position, fullTarget.get().position)) {
            transform(world, scheduler, imageStore);
            return;
        }

        List<MyPoint> points = strategy.computePath(this.position, fullTarget.get().position,
                p ->  world.withinBounds(p) && world.getOccupancyCell(p) == null ||
                        world.withinBounds(p) && world.getOccupancyCell(p) instanceof Stump,
                (p1, p2) -> neighbors(p1,p2),
                PathingStrategy.CARDINAL_NEIGHBORS);

        if (!points.isEmpty()) {
            world.moveEntity(scheduler, this, points.get(0));
        }

//        if (fullTarget.isPresent() && this.moveTo(world, fullTarget.get(), scheduler)) {
//            this.transform(world, scheduler, imageStore);
//        } else {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
    }

}
