import processing.core.PImage;

import java.util.List;

public abstract class Plant extends Entity{

    protected int health;

    public Plant(String id, MyPoint position, List<PImage> images, int health) {
        super(id, position, images);
        this.health = health;
    }

    public void reduceHealth() {
        this.health--;
    }

    @Override
    public String toString() {
        return super.toString() + " : " + health;
    }
}
