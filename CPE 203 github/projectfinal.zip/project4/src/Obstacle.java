import processing.core.PImage;

import java.util.List;

public class Obstacle extends Entity implements Animatable {
    private double animationPeriod;

    public Obstacle(String id, MyPoint position, List<PImage> images, double animationPeriod) {
        super(id, position, images);
        this.animationPeriod = animationPeriod;
    }

    public static Obstacle createObstacle(String id, MyPoint position, double animationPeriod, List<PImage> images) {
        return new Obstacle(id, position, images, animationPeriod);
    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }
}
