import java.util.List;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.LinkedList;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.HashMap;
import java.util.Comparator;

class AStarPathingStrategy implements PathingStrategy {




    public List<MyPoint> computePath(MyPoint start, MyPoint end,
                                     Predicate<MyPoint> canPassThrough,
                                     BiPredicate<MyPoint, MyPoint> withinReach,
                                     Function<MyPoint, Stream<MyPoint>> potentialNeighbors)
    {
        /*define closed list
          define open list
          while (true){
            Filtered list containing neighbors you can actually move to
            Check if any of the neighbors are beside the target
            set the g, h, f values
            add them to open list if not in open list
            add the selected node to close list
          return path */
        List<MyPoint> path = new LinkedList<>();
        ArrayList<MyPoint> closedList = new ArrayList<>();
        HashMap<MyPoint, MyPoint> previous = new HashMap<>();
        previous.put(start, null);
        HashMap<MyPoint, Integer> h = new HashMap<>(); // guess from current node to end
        HashMap<MyPoint, Integer> g = new HashMap<>(); // current node to start
        HashMap<MyPoint, Integer> f = new HashMap<>(); // g + h
        f.put(start, 0);

        PriorityQueue<MyPoint> openList = new PriorityQueue<>(new Comparator<MyPoint>(){
            @Override
            public int compare(MyPoint o1, MyPoint o2) {
                return f.get(o1) - f.get(o2);
            }
        });

        openList.add(start);
        g.put(start, 0);

        while (!openList.isEmpty()) {
            MyPoint top = openList.remove();
            if (withinReach.test(top, end)) {
                path.add(top);
                break;
            }
            closedList.add(top);
            // check all viable neighbors
            for (MyPoint p: potentialNeighbors.apply(top).filter(canPassThrough).filter(p -> !closedList.contains(p)).toList()) {
                g.put(p, g.get(top) + 1);
                h.put(p, Math.abs(p.y - end.y) + Math.abs(p.x - end.x));
                int newF = g.get(p) + h.get(p);
                if (f.containsKey(p) && f.get(p) > newF) {
                    f.put(p, newF);
                    openList.remove(p);
                    openList.add(p);
                    previous.put(p, top);
                } else if (!f.containsKey(p)) {
                    f.put(p, newF);
                    openList.add(p);
                    previous.put(p, top);
                }
            }
        }

        while (!path.isEmpty() && previous.get(path.get(0)) != null) {
            path.add(0, previous.get(path.get(0)));
        }
        if (!path.isEmpty()) {
            path.remove(0);
        }
         return path;
    }
}
