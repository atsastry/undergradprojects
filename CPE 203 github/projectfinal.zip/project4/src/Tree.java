import processing.core.PImage;

import java.util.List;

public class Tree extends Plant implements Transformable, Animatable, ActivityAction{
      private double actionPeriod;
      private double animationPeriod;

    public Tree(String id, MyPoint position, List<PImage> images, double actionPeriod, double animationPeriod, int health) {
        super(id, position, images, health);
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
    }

    public static Tree createTree(String id, MyPoint position, List<PImage> images, double actionPeriod, double animationPeriod, int health) {
        return new Tree(id, position, images, actionPeriod, animationPeriod, health);
    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }

    @Override
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        if (this.health <= 0) {
            Entity stump = Stump.createStump(STUMP_KEY + "_" + this.id, this.position, imageStore.getImageList(STUMP_KEY));

            world.removeEntity(scheduler, this);

            world.addEntity(stump);

            return true;
        }

        return false;
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {

        if (!this.transform(world, scheduler, imageStore)) {

            scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        }
    }
}
