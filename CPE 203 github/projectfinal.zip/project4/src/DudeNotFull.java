import processing.core.PImage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class DudeNotFull extends Entity implements Transformable, Movable, Animatable, ActivityAction {
    private int resourceLimit;
    private int resourceCount;
    private double actionPeriod;
    private double animationPeriod;
    private PathingStrategy strategy;


    public DudeNotFull(String id, MyPoint position, List<PImage> images, int resourceLimit, int resourceCount, double actionPeriod, double animationPeriod) {
        super(id, position, images);
        this.resourceLimit = resourceLimit;
        this.resourceCount = resourceCount;
        this.actionPeriod = actionPeriod;
        this.animationPeriod = animationPeriod;
        this.strategy = new AStarPathingStrategy();
    }

    public static DudeNotFull createDudeNotFull(String id, MyPoint position, double actionPeriod, double animationPeriod, int resourceLimit, List<PImage> images) {
        return new DudeNotFull(id, position, images, resourceLimit, 0, actionPeriod, animationPeriod);
    }

    @Override
    public void executeActivity(WorldModel world, ImageStore imageStore, EventScheduler scheduler) {
        Optional<Entity> target = this.position.findNearest(world, new ArrayList<>(Arrays.asList(Tree.class, Sapling.class)));

        if (target.isEmpty()) {
            scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
            return;
        }

        if (neighbors(this.position, target.get().position)) {
            this.resourceCount += 1;
//            if (target.get() instanceof Plant) {
//                System.out.println("health before" + target.get());
                ((Plant)target.get()).reduceHealth();
//                System.out.println("health after" + target.get());
//            }
            if (this.resourceCount == this.resourceLimit) {
                transform(world, scheduler, imageStore); // transform to a full
                return;
            }
            scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
            return;
        }

        List<MyPoint> points = strategy.computePath(this.position, target.get().position,
                p ->  world.withinBounds(p) && world.getOccupancyCell(p) == null ||
                        world.withinBounds(p) && world.getOccupancyCell(p) instanceof Stump,
                (p1, p2) -> neighbors(p1,p2),
                PathingStrategy.CARDINAL_NEIGHBORS);

        if (!points.isEmpty()) {
            world.moveEntity(scheduler, this, points.get(0));
        }
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);

    }

    @Override
    public double getAnimationPeriod() {
        return this.animationPeriod;
    }

    @Override
    public void scheduleActions(EventScheduler scheduler, WorldModel world, ImageStore imageStore) {
        scheduler.scheduleEvent(this, new Activity(this, world, imageStore, 0), this.actionPeriod);
        scheduler.scheduleEvent(this, new Animation(this, 0), this.getAnimationPeriod());
    }

    @Override
    public boolean moveTo(WorldModel world, Entity target, EventScheduler scheduler) {
        if (this.position.adjacent(target.position)) {
            this.resourceCount += 1;
            if (target instanceof Plant) {
                ((Plant)target).reduceHealth();
            }
            return true;
        } else {
            MyPoint nextPos = this.nextPosition(world, target.position);

            if (!this.position.equals(nextPos)) {
                world.moveEntity(scheduler, this, nextPos);
            }
            return false;
        }
    }

    @Override
    public MyPoint nextPosition(WorldModel world, MyPoint destPos) {
        int horiz = Integer.signum(destPos.x - this.position.x);
        MyPoint newPos = new MyPoint(this.position.x + horiz, this.position.y);

        if (horiz == 0 || world.isOccupied(newPos) && !(world.getOccupancyCell(newPos) instanceof Stump)) {
            int vert = Integer.signum(destPos.y - this.position.y);
            newPos = new MyPoint(this.position.x, this.position.y + vert);

            if (vert == 0 || world.isOccupied(newPos) && !(world.getOccupancyCell(newPos) instanceof Stump)) {
                newPos = this.position;
            }
        }

        return newPos;
    }

    @Override
    public boolean transform(WorldModel world, EventScheduler scheduler, ImageStore imageStore) {
        if (this.resourceCount >= this.resourceLimit) {
            DudeFull dude = DudeFull.createDudeFull(this.id, this.position, this.actionPeriod, this.animationPeriod, this.resourceLimit, this.images);

            world.removeEntity(scheduler, this);
            scheduler.unscheduleAllEvents(this);

            world.addEntity(dude);
            dude.scheduleActions(scheduler, world, imageStore);

            return true;
        }

        return false;
    }

//    private boolean neighbors(Point p1, Point p2)   {
//        return p1.x+1 == p2.x && p1.y == p2.y ||
//                p1.x-1 == p2.x && p1.y == p2.y ||
//                p1.x == p2.x && p1.y+1 == p2.y ||
//                p1.x == p2.x && p1.y-1 == p2.y;
//    }

}
