import java.util.HashSet;

public class Game {
    private HashSet<Integer> winningNumber;

    public Game() {
        winningNumber = new HashSet<Integer>(5);
    }

    public void winningLotNumber() {
        winningNumber.clear();
        int numCount = 0;
        while (numCount < 5) {
            if (winningNumber.add((int)(Math.random()*42) + 1)) {
                numCount++;
            }
        }
    }

    public int numberMatches(HashSet<Integer> playerValues) {
        int count = 0;
        for (Integer object : playerValues) {
            if (winningNumber.contains(object)) {
                count++;
            }
        }
        return count;
    }

    public float results(Player player) {
        int matches = numberMatches(player.getLottery());
        switch (matches) {
            case 1:
                return -1.0f;
            case 2:
                return 1.0f;
            case 3:
                return 10.86f;
            case 4:
                return 197.53f;
            case 5:
                return 212534.83f;
        }
        return -1.0f;
    }
}

