import java.util.*;

public final class CommunityLSim {
   //instance variables
  ArrayList<Player> players;
  ArrayList<Integer> playerIndices;

  HashSet<Integer> comm;

	int numPeeps;
  Random random = new Random();
  //TODO: you will need to add more instance variables
  
  //Constructor
  public CommunityLSim( int numP) {
		numPeeps = numP;
		//create the players
  		this.players = new ArrayList<>();
		  this.playerIndices = new ArrayList<>();
	  this.comm = new HashSet<Integer>();


		//generate a community of 30
		for (int i = 0; i < numPeeps; i++) {
			if (i < numPeeps/2.0)
				players.add(new Player(PlayerKind.POORLY_PAID, (float)(99+Math.random()))); 
			else
				players.add(new Player(PlayerKind.WELL_PAID, (float)(100.1+Math.random()))); 
		}
	
	}

	public int getSize() {return numPeeps;	}

	public Player getPlayer(int i) {return players.get(i);	}
   // TODO
	public void addPocketChange() {
		for (Player player: players) {
			if (player.getKind() == PlayerKind.WELL_PAID) {
				player.addFunds(0.1f);
			}
			else {
				player.addFunds(0.03f);
			}
		}
   
   }

	private void reDoWhoPlays() {
//	  playerIndices.clear();
		int i = (int)(numPeeps/2*0.6);
		randomUniqIndx(i,0, numPeeps/2);
		i += (int)(numPeeps/2*0.4);
		randomUniqIndx(i, numPeeps/2, numPeeps);
//		playerIndices.addAll(comm);
  }


	/*TODO generate some random indices for who might play the lottery 
		in a given range of indices */ 
 	public void randomUniqIndx(int numI, int startRange, int endRange) {
		 while (comm.size() < numI) {
			 comm.add((int)(random.nextInt(endRange-startRange)+startRange));
		 }
	}

	public void scholarship() {
		int rand = random.nextInt(10);
		 if (rand < 3) {
			 int poor = random.nextInt(numPeeps/2);
			 players.get(poor).addFunds(1.0f);
		 }
		 else {
			 int rich = random.nextInt(numPeeps - numPeeps/2) + numPeeps/2;
			 players.get(rich).addFunds(1.0f);

		 }
	}
    
	public void simulateYears(int numYears) {
  		/*now simulate lottery play for some years */
		Game lotto = new Game();
  		for (int year=0; year < numYears; year++) {
			lotto.winningLotNumber();
			reDoWhoPlays();
			addPocketChange();
			// TODO: add code so that each member of the community who plays, plays
			for (int i : comm) {
				System.out.println(i);
				players.get(i).playRandom();
				float winnings = lotto.results(players.get(i));
				players.get(i).addFunds(winnings);
				if (winnings < 0) {
					scholarship();
				}
			}
			//right now just everyone updates their list of funds each year
			for (Player p : players) {
				p.updateMoneyEachYear();
			}
			printMoney(numYears);
    	}

  }

	public float mostMoney(int year){
		float money = players.get(0).getPastMoney(year);;
		for(Player player : players){
			if(player.getPastMoney(year) > money){
				money = player.getPastMoney(year);
			}
		}
		return money;
	}

	public float leastMoney(int year){
		float money = players.get(0).getPastMoney(year);
		for(Player player : players){
			if(player.getPastMoney(year) < money){
				money = player.getPastMoney(year);
			}
		}
		return money;
	}

  public void printMoney(int years) {
		 for (int i = 0; i < years; i++) {
			 System.out.println("After year "+i+":");
			 System.out.println("The person with the most money has: "+ mostMoney(i));
			 System.out.println("The person with the least money has: "+ leastMoney(i));
		 }
  }


}
