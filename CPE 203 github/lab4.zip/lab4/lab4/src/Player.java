import java.util.*;

class Player {
   //instance variables
	private PlayerKind kind;
	private float money;
	private ArrayList<Float> moneyOverTime;
    private Random random = new Random();
	private int red, green, blue;

	private HashSet<Integer> lottery;

	//constructor
	public Player(PlayerKind pK, float startFunds) {
		kind = pK;
		money = startFunds;
		moneyOverTime = new ArrayList<Float>();
		moneyOverTime.add(startFunds);
		red = random.nextInt(100);
		green = random.nextInt(100);
		blue = random.nextInt(100);
		lottery = new HashSet<Integer>(5);

		//overall blue tint to POORLY_PAID	
		if (kind == PlayerKind.WELL_PAID) {
			red += 100;
		} else {
			blue += 100;
		}
	}

	public void addFunds(float x) {
		this.money += x;
	}

	public float getPastMoney(int year){
		if(year >= 0 && year < moneyOverTime.size()){
			return moneyOverTime.get(year);
		}
		return 0.0f;
	}

	public int getR() { return red; }
	public int getG() { return green; }
	public int getB() { return blue; }
	public float getMoney() { return money; }
	public PlayerKind getKind() { return kind; }
	public ArrayList<Float> getFunds() { return moneyOverTime; }

	public HashSet<Integer> getLottery() {
		return lottery;
	}

	public void updateMoneyEachYear() {
		moneyOverTime.add(money);
	}

	public void playRandom() {
		lottery.clear();
		int num = 0;
		while (num < 5) {
			if (lottery.add((int)(Math.random()*42) + 1)) {
				num++;
			}
		}
	}

}
