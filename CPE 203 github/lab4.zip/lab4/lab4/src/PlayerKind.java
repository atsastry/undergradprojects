enum PlayerKind {
	WELL_PAID,
	POORLY_PAID
}
